OmniAI Assistant
Virtual AI assistant in chat supporting OpenAI, Groq, Gemini, and custom Ollama servers with command execution.

NeoForge untuk Minecraft 1.21.1 (Java 21).
Build: jalankan "gradle build". File .jar ada di build/libs/.
GitHub: unggah isi folder ini ke repositori; workflow .github/workflows/build.yml akan membangun .jar otomatis (tab Actions, lalu Artifacts).
Manifest (MANIFEST.MF) dibuat otomatis oleh Gradle dari blok jar { manifest } di build.gradle.
Versi alat Gradle/loader di gradle.properties dan build.gradle perlu dicek di situs resmi.

package com.modbuilder.omniai_assistant;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import net.minecraft.server.level.ServerPlayer;

/**
 * Registrasi payload jaringan NeoForge untuk mod ini.
 *
 * Saat ini hanya ada satu payload: {@link OpenMenuPayload}, yang dikirim dari
 * server ke klien agar layar pengaturan terbuka (misalnya lewat "/ai menu").
 */
public final class NetworkHandler {

    /** Versi protokol jaringan. Naikkan jika format payload berubah. */
    public static final String PROTOCOL_VERSION = "1";

    private NetworkHandler() {
    }

    /**
     * Dipanggil lewat mod event bus pada RegisterPayloadHandlersEvent.
     */
    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar(PROTOCOL_VERSION).optional();

        registrar.playToClient(
                OpenMenuPayload.TYPE,
                OpenMenuPayload.STREAM_CODEC,
                NetworkHandler::handleOpenMenu
        );
    }

    /**
     * Mengirim permintaan pembukaan menu ke klien milik pemain tertentu.
     */
    public static void sendOpenMenu(ServerPlayer player) {
        if (player == null) {
            return;
        }
        PacketDistributor.sendToPlayer(player, OpenMenuPayload.INSTANCE);
    }

    /**
     * Handler sisi klien. Berjalan di thread utama klien sehingga aman
     * untuk membuka Screen secara langsung.
     */
    private static void handleOpenMenu(OpenMenuPayload payload, IPayloadContext context) {
        if (FMLEnvironment.dist != Dist.CLIENT) {
            return;
        }
        context.enqueueWork(ClientSetup::openSettingsScreen)
                .exceptionally(error -> {
                    ModMain.LOGGER.error("Gagal membuka layar pengaturan OmniAI", error);
                    return null;
                });
    }
}
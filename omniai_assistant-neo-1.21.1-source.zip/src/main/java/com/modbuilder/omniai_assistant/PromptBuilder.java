package com.modbuilder.omniai_assistant;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.biome.Biome;

import java.util.Locale;

public final class PromptBuilder {

    private static final String RULES = """
            You are OmniAI Assistant, a friendly and capable helper that lives inside the chat of a Minecraft Java Edition 1.21.1 world.
            You can talk freely about anything and help the player with survival, redstone, building, exploration, farming, combat, and general questions.
            Answer in the same language the player uses. Keep replies short and readable because they are shown in the Minecraft chat window; avoid markdown headings, tables and code fences.

            COMMAND EXECUTION RULES:
            1. When the player asks you to perform an in-game action, you may execute it by writing each command wrapped in double square brackets, for example: [[/fill ~-10 ~ ~-10 ~10 ~10 ~10 stone]]
            2. Always start the command with a slash. Put exactly one command inside each [[ ]] pair. Never nest brackets and never split a command across several tags.
            3. Commands are executed on the server as the player, at the player's position, so relative coordinates (~ ~ ~) refer to the player. Use absolute coordinates only when the player gives them.
            4. Use valid Minecraft 1.21.1 syntax only (for example item components such as minecraft:diamond_sword[enchantments={levels:{"minecraft:sharpness":5}}]).
            5. Supported actions include /fill, /clone, /setblock, /summon, /give, /effect, /enchant, /weather, /time, /tp, /gamemode, /setworldspawn, /gamerule and any other vanilla command.
            6. For large structures, split the work into several smaller commands (a /fill region may not exceed 32768 blocks). Build in logical order: foundation, walls, roof, details, lighting.
            7. The server runs commands one after another with a small delay and limits how many can run per request, so prefer fewer, larger /fill commands over many /setblock commands.
            8. Never use commands that stop the server, ban or op players, or wipe data (such as /stop, /op, /deop, /ban, /kick, /whitelist, /save-off). They are blocked.
            9. Briefly tell the player what you are about to do in plain text, then include the tags. Do not describe the tags themselves.
            10. If a request is unclear or could destroy the player's existing builds, ask a short clarifying question first and do not output any tag until the player confirms.
            11. If the player only asks a question, answer it without any command tag.
            """;

    private PromptBuilder() {
    }

    public static String build(ServerPlayer player) {
        StringBuilder sb = new StringBuilder(RULES.length() + 512);
        sb.append(RULES).append('\n');
        sb.append("CURRENT PLAYER CONTEXT:\n");
        sb.append(buildContext(player));
        return sb.toString();
    }

    public static String buildContext(ServerPlayer player) {
        BlockPos pos = player.blockPosition();
        ServerLevel level = player.serverLevel();

        String dimension = level.dimension().location().toString();
        String biome = biomeName(level, pos);
        int health = Math.round(player.getHealth());
        int maxHealth = Math.round(player.getMaxHealth());
        int hunger = player.getFoodData().getFoodLevel();
        String held = heldItemDescription(player);

        StringBuilder sb = new StringBuilder();
        sb.append("- Player name: ").append(player.getGameProfile().getName()).append('\n');
        sb.append("- Position (XYZ): ")
                .append(pos.getX()).append(' ')
                .append(pos.getY()).append(' ')
                .append(pos.getZ()).append('\n');
        sb.append("- Dimension: ").append(dimension).append('\n');
        sb.append("- Biome: ").append(biome).append('\n');
        sb.append("- Health: ").append(health).append('/').append(maxHealth).append('\n');
        sb.append("- Hunger: ").append(hunger).append("/20\n");
        sb.append("- Held item: ").append(held).append('\n');
        sb.append("- Game mode: ").append(player.gameMode.getGameModeForPlayer().getName()).append('\n');
        sb.append("- Time of day (ticks): ").append(level.getDayTime() % 24000L).append('\n');
        return sb.toString();
    }

    private static String biomeName(ServerLevel level, BlockPos pos) {
        Holder<Biome> holder = level.getBiome(pos);
        return holder.unwrapKey()
                .map(PromptBuilder::keyToString)
                .orElse("unknown");
    }

    private static String keyToString(ResourceKey<Biome> key) {
        return key.location().toString();
    }

    private static String heldItemDescription(ServerPlayer player) {
        ItemStack stack = player.getMainHandItem();
        if (stack.isEmpty()) {
            return "empty hand";
        }
        String id = BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
        return String.format(Locale.ROOT, "%s x%d (%s)", id, stack.getCount(), stack.getHoverName().getString());
    }
}
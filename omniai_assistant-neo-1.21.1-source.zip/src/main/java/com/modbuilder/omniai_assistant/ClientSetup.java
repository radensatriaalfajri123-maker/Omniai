package com.modbuilder.omniai_assistant;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.settings.KeyConflictContext;
import net.neoforged.neoforge.common.NeoForge;
import org.lwjgl.glfw.GLFW;

/**
 * Pengaturan sisi klien: mendaftarkan tombol 'K' dan membuka layar pengaturan
 * ketika tombol ditekan atau ketika server meminta klien membuka menu.
 */
public final class ClientSetup {

    public static final String KEY_CATEGORY = "key.categories." + ModMain.MOD_ID;
    public static final String KEY_OPEN_MENU_NAME = "key." + ModMain.MOD_ID + ".open_menu";

    public static final KeyMapping OPEN_MENU_KEY = new KeyMapping(
            KEY_OPEN_MENU_NAME,
            KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_K,
            KEY_CATEGORY
    );

    private ClientSetup() {
    }

    /**
     * Dipanggil dari ModMain hanya pada sisi klien.
     */
    public static void init(IEventBus modEventBus) {
        modEventBus.addListener(ClientSetup::onRegisterKeyMappings);
        NeoForge.EVENT_BUS.addListener(ClientSetup::onClientTick);
    }

    private static void onRegisterKeyMappings(RegisterKeyMappingsEvent event) {
        event.register(OPEN_MENU_KEY);
    }

    private static void onClientTick(ClientTickEvent.Post event) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || minecraft.level == null) {
            return;
        }
        while (OPEN_MENU_KEY.consumeClick()) {
            if (minecraft.screen == null) {
                openSettings();
            }
        }
    }

    /**
     * Membuka layar pengaturan di thread klien. Aman dipanggil dari thread mana pun.
     */
    public static void openSettings() {
        Minecraft minecraft = Minecraft.getInstance();
        minecraft.execute(() -> {
            if (minecraft.player == null) {
                return;
            }
            minecraft.setScreen(new SettingsScreen(minecraft.screen));
        });
    }
}
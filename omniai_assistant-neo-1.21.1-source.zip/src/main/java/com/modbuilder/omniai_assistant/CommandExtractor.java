package com.modbuilder.omniai_assistant;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Mendeteksi tag [[/command]] di dalam balasan AI, lalu memisahkan teks yang
 * aman ditampilkan di chat dari daftar command yang harus dijalankan.
 */
public final class CommandExtractor {

    /**
     * Cocok dengan [[ ... ]] yang isinya diawali slash. Isi tidak boleh memuat
     * tanda kurung siku sehingga tag bersarang tidak ikut tertangkap.
     */
    private static final Pattern TAG = Pattern.compile("\\[\\[\\s*(/[^\\[\\]\\r\\n]*?)\\s*\\]\\]");

    private static final Pattern MULTI_SPACE = Pattern.compile("[ \\t]{2,}");
    private static final Pattern SPACE_BEFORE_NEWLINE = Pattern.compile("[ \\t]+\\n");
    private static final Pattern MANY_NEWLINES = Pattern.compile("\\n{3,}");

    private CommandExtractor() {
    }

    /**
     * Hasil ekstraksi: teks bersih tanpa tag dan daftar command (tanpa slash awal).
     */
    public record Result(String cleanText, List<String> commands) {

        public Result {
            commands = Collections.unmodifiableList(new ArrayList<>(commands));
        }

        public boolean hasCommands() {
            return !commands.isEmpty();
        }
    }

    public static Result extract(String reply) {
        if (reply == null || reply.isEmpty()) {
            return new Result("", List.of());
        }

        List<String> commands = new ArrayList<>();
        Matcher matcher = TAG.matcher(reply);
        StringBuilder clean = new StringBuilder();

        while (matcher.find()) {
            String command = normalize(matcher.group(1));
            if (!command.isEmpty()) {
                commands.add(command);
            }
            matcher.appendReplacement(clean, "");
        }
        matcher.appendTail(clean);

        return new Result(tidy(clean.toString()), commands);
    }

    /**
     * Membuang slash di depan dan spasi berlebih sehingga string siap dikirim
     * ke dispatcher command Minecraft.
     */
    private static String normalize(String raw) {
        String command = raw.trim();
        while (command.startsWith("/")) {
            command = command.substring(1).trim();
        }
        return command;
    }

    private static String tidy(String text) {
        String result = text.replace("\r\n", "\n");
        result = MULTI_SPACE.matcher(result).replaceAll(" ");
        result = SPACE_BEFORE_NEWLINE.matcher(result).replaceAll("\n");
        result = MANY_NEWLINES.matcher(result).replaceAll("\n\n");
        return result.trim();
    }
}
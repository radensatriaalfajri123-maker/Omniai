package com.modbuilder.omniai_assistant;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Payload kosong yang dikirim dari server ke klien untuk meminta klien
 * membuka layar pengaturan OmniAI (misalnya saat pemain menjalankan "/ai menu").
 * Payload ini tidak membawa data apa pun, sehingga cukup memakai satu instance tunggal.
 */
public final class OpenMenuPayload implements CustomPacketPayload {

    public static final OpenMenuPayload INSTANCE = new OpenMenuPayload();

    public static final CustomPacketPayload.Type<OpenMenuPayload> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(ModMain.MOD_ID, "open_menu"));

    /**
     * Codec tanpa data: tidak menulis apa pun ke buffer dan selalu mengembalikan INSTANCE saat dibaca.
     */
    public static final StreamCodec<RegistryFriendlyByteBuf, OpenMenuPayload> STREAM_CODEC =
            StreamCodec.unit(INSTANCE);

    private OpenMenuPayload() {
    }

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
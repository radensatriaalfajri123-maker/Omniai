package com.modbuilder.omniai_assistant;

import java.util.Locale;

public enum AiProvider {

    OPENAI("OpenAI", "https://api.openai.com/v1/chat/completions", true, "gpt-4o-mini"),
    GROQ("Groq", "https://api.groq.com/openai/v1/chat/completions", true, "llama-3.3-70b-versatile"),
    GEMINI("Gemini", "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions", true, "gemini-2.5-flash"),
    OLLAMA("Ollama", "http://localhost:11434/v1/chat/completions", false, "qwen2.5-coder");

    private final String label;
    private final String defaultUrl;
    private final boolean apiKeyRequired;
    private final String defaultModel;

    AiProvider(String label, String defaultUrl, boolean apiKeyRequired, String defaultModel) {
        this.label = label;
        this.defaultUrl = defaultUrl;
        this.apiKeyRequired = apiKeyRequired;
        this.defaultModel = defaultModel;
    }

    public String getLabel() {
        return label;
    }

    public String getDefaultUrl() {
        return defaultUrl;
    }

    public boolean isApiKeyRequired() {
        return apiKeyRequired;
    }

    public String getDefaultModel() {
        return defaultModel;
    }

    public AiProvider cycle() {
        AiProvider[] all = values();
        int next = (this.ordinal() + 1) % all.length;
        return all[next];
    }

    public static boolean isDefaultUrl(String url) {
        if (url == null) {
            return false;
        }
        String trimmed = url.trim();
        for (AiProvider provider : values()) {
            if (provider.defaultUrl.equals(trimmed)) {
                return true;
            }
        }
        return false;
    }

    private boolean matches(String normalized) {
        if (this.name().equals(normalized)) {
            return true;
        }
        String upperLabel = this.label.toUpperCase(Locale.ROOT);
        return upperLabel.equals(normalized);
    }

    public static AiProvider fromName(String name) {
        if (name == null) {
            return OPENAI;
        }
        String normalized = name.trim().toUpperCase(Locale.ROOT);
        for (AiProvider provider : values()) {
            if (provider.matches(normalized)) {
                return provider;
            }
        }
        return OPENAI;
    }

    @Override
    public String toString() {
        return label;
    }
}
package com.modbuilder.omniai_assistant;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Mendaftarkan command Brigadier /ai.
 * <ul>
 *   <li>/ai menu : meminta klien pemain membuka layar pengaturan.</li>
 *   <li>/ai &lt;pesan&gt; : mengirim pesan bebas ke asisten AI.</li>
 * </ul>
 */
public final class AiCommands {

    private static final String ROOT = "ai";
    private static final String ARG_MESSAGE = "message";
    private static final int MAX_MESSAGE_LENGTH = 2000;

    private AiCommands() {
    }

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(
                Commands.literal(ROOT)
                        .then(Commands.literal("menu")
                                .executes(AiCommands::openMenu))
                        .then(Commands.argument(ARG_MESSAGE, StringArgumentType.greedyString())
                                .executes(AiCommands::chat))
        );
    }

    private static int openMenu(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        ServerPlayer player = context.getSource().getPlayerOrException();
        PacketDistributor.sendToPlayer(player, OpenMenuPayload.INSTANCE);
        return 1;
    }

    private static int chat(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        CommandSourceStack source = context.getSource();
        ServerPlayer player = source.getPlayerOrException();

        String message = StringArgumentType.getString(context, ARG_MESSAGE).trim();
        if (message.isEmpty()) {
            source.sendFailure(Component.literal("[AI]: Pesan tidak boleh kosong."));
            return 0;
        }
        if (message.length() > MAX_MESSAGE_LENGTH) {
            source.sendFailure(Component.literal(
                    "[AI]: Pesan terlalu panjang (maksimal " + MAX_MESSAGE_LENGTH + " karakter)."));
            return 0;
        }

        ChatService.handleMessage(player, message);
        return 1;
    }
}
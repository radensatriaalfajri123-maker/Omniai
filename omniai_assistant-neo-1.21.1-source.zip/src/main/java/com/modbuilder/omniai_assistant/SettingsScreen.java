package com.modbuilder.omniai_assistant;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.net.URI;
import java.util.Locale;

public class SettingsScreen extends Screen {

    private static final int FIELD_WIDTH = 240;
    private static final int FIELD_HEIGHT = 20;
    private static final int ROW_GAP = 36;

    private final Screen parent;

    private AiProvider selectedProvider;
    private String urlValue;
    private String keyValue;
    private String modelValue;

    private Button providerButton;
    private EditBox urlBox;
    private EditBox keyBox;
    private EditBox modelBox;
    private Button saveButton;

    private Component statusMessage = Component.empty();

    public SettingsScreen() {
        this(null);
    }

    public SettingsScreen(Screen parent) {
        super(Component.translatable("gui." + ModMain.MOD_ID + ".settings.title"));
        this.parent = parent;
        AiConfig config = AiConfig.get();
        this.selectedProvider = config.provider != null ? config.provider : AiProvider.OPENAI;
        this.urlValue = config.endpointUrl != null ? config.endpointUrl : this.selectedProvider.getDefaultUrl();
        this.keyValue = config.apiKey != null ? config.apiKey : "";
        this.modelValue = config.modelName != null ? config.modelName : this.selectedProvider.getDefaultModel();
    }

    @Override
    protected void init() {
        int left = this.width / 2 - FIELD_WIDTH / 2;
        int top = this.height / 2 - 92;

        this.providerButton = Button.builder(providerLabel(), button -> onProviderCycle())
                .bounds(left, top, FIELD_WIDTH, FIELD_HEIGHT)
                .build();
        this.addRenderableWidget(this.providerButton);

        this.urlBox = new EditBox(this.font, left, top + ROW_GAP + 12, FIELD_WIDTH, FIELD_HEIGHT,
                Component.translatable("gui." + ModMain.MOD_ID + ".settings.url"));
        this.urlBox.setMaxLength(512);
        this.urlBox.setValue(this.urlValue);
        this.urlBox.setResponder(value -> this.urlValue = value);
        this.addRenderableWidget(this.urlBox);

        this.keyBox = new EditBox(this.font, left, top + ROW_GAP * 2 + 12, FIELD_WIDTH, FIELD_HEIGHT,
                Component.translatable("gui." + ModMain.MOD_ID + ".settings.api_key"));
        this.keyBox.setMaxLength(512);
        this.keyBox.setFormatter((text, offset) ->
                net.minecraft.util.FormattedCharSequence.forward("*".repeat(text.length()), net.minecraft.network.chat.Style.EMPTY));
        this.keyBox.setValue(this.keyValue);
        this.keyBox.setResponder(value -> this.keyValue = value);
        this.addRenderableWidget(this.keyBox);

        this.modelBox = new EditBox(this.font, left, top + ROW_GAP * 3 + 12, FIELD_WIDTH, FIELD_HEIGHT,
                Component.translatable("gui." + ModMain.MOD_ID + ".settings.model"));
        this.modelBox.setMaxLength(256);
        this.modelBox.setValue(this.modelValue);
        this.modelBox.setResponder(value -> this.modelValue = value);
        this.addRenderableWidget(this.modelBox);

        int buttonY = top + ROW_GAP * 4 + 20;
        int half = (FIELD_WIDTH - 8) / 2;
        this.saveButton = Button.builder(Component.translatable("gui." + ModMain.MOD_ID + ".settings.save"), button -> onSave())
                .bounds(left, buttonY, half, FIELD_HEIGHT)
                .build();
        this.addRenderableWidget(this.saveButton);

        this.addRenderableWidget(Button.builder(Component.translatable("gui." + ModMain.MOD_ID + ".settings.cancel"), button -> onClose())
                .bounds(left + half + 8, buttonY, half, FIELD_HEIGHT)
                .build());

        this.setInitialFocus(this.urlBox);
    }

    private Component providerLabel() {
        return Component.translatable("gui." + ModMain.MOD_ID + ".settings.provider", this.selectedProvider.getLabel());
    }

    private void onProviderCycle() {
        AiProvider previous = this.selectedProvider;
        this.selectedProvider = previous.cycle();

        String currentUrl = this.urlBox.getValue();
        if (currentUrl.isBlank() || AiProvider.isDefaultUrl(currentUrl)) {
            this.urlBox.setValue(this.selectedProvider.getDefaultUrl());
        }

        String currentModel = this.modelBox.getValue().trim();
        if (currentModel.isEmpty() || currentModel.equals(previous.getDefaultModel())) {
            this.modelBox.setValue(this.selectedProvider.getDefaultModel());
        }

        this.providerButton.setMessage(providerLabel());
        this.statusMessage = Component.empty();
    }

    private void onSave() {
        String url = this.urlBox.getValue().trim();
        String key = this.keyBox.getValue().trim();
        String model = this.modelBox.getValue().trim();

        if (url.isEmpty()) {
            url = this.selectedProvider.getDefaultUrl();
            this.urlBox.setValue(url);
        }

        Component urlError = validateUrl(url);
        if (urlError != null) {
            this.statusMessage = urlError.copy().withStyle(ChatFormatting.RED);
            return;
        }

        if (model.isEmpty()) {
            this.statusMessage = Component.translatable("gui." + ModMain.MOD_ID + ".settings.error.model_empty")
                    .withStyle(ChatFormatting.RED);
            return;
        }

        if (this.selectedProvider.isApiKeyRequired() && key.isEmpty()) {
            this.statusMessage = Component.translatable("gui." + ModMain.MOD_ID + ".settings.error.key_required",
                    this.selectedProvider.getLabel()).withStyle(ChatFormatting.RED);
            return;
        }

        AiConfig config = AiConfig.get();
        config.provider = this.selectedProvider;
        config.endpointUrl = url;
        config.apiKey = key;
        config.modelName = model;
        AiConfig.save();

        this.statusMessage = Component.translatable("gui." + ModMain.MOD_ID + ".settings.saved")
                .withStyle(ChatFormatting.GREEN);
        this.onClose();
    }

    private Component validateUrl(String url) {
        URI uri;
        try {
            uri = URI.create(url);
        } catch (IllegalArgumentException e) {
            return Component.translatable("gui." + ModMain.MOD_ID + ".settings.error.url_invalid");
        }

        String scheme = uri.getScheme();
        String host = uri.getHost();
        if (scheme == null || host == null) {
            return Component.translatable("gui." + ModMain.MOD_ID + ".settings.error.url_invalid");
        }

        scheme = scheme.toLowerCase(Locale.ROOT);
        if (!scheme.equals("http") && !scheme.equals("https")) {
            return Component.translatable("gui." + ModMain.MOD_ID + ".settings.error.url_invalid");
        }

        if (this.selectedProvider == AiProvider.OLLAMA && !AiProvider.isDefaultUrl(url)) {
            boolean local = isLocalHost(host);
            if (!scheme.equals("https") && !local) {
                return Component.translatable("gui." + ModMain.MOD_ID + ".settings.error.https_required");
            }
        } else if (!this.selectedProvider.equals(AiProvider.OLLAMA) && !scheme.equals("https")) {
            return Component.translatable("gui." + ModMain.MOD_ID + ".settings.error.https_required");
        }
        return null;
    }

    private static boolean isLocalHost(String host) {
        String h = host.toLowerCase(Locale.ROOT);
        return h.equals("localhost") || h.equals("127.0.0.1") || h.equals("::1") || h.equals("[::1]");
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);

        int left = this.width / 2 - FIELD_WIDTH / 2;
        int top = this.height / 2 - 92;

        graphics.drawCenteredString(this.font, this.title, this.width / 2, top - 28, 0xFFFFFF);

        graphics.drawString(this.font, Component.translatable("gui." + ModMain.MOD_ID + ".settings.url"),
                left, top + ROW_GAP, 0xA0A0A0, false);

        Component keyLabel = this.selectedProvider.isApiKeyRequired()
                ? Component.translatable("gui." + ModMain.MOD_ID + ".settings.api_key")
                : Component.translatable("gui." + ModMain.MOD_ID + ".settings.api_key_optional");
        graphics.drawString(this.font, keyLabel, left, top + ROW_GAP * 2, 0xA0A0A0, false);

        graphics.drawString(this.font, Component.translatable("gui." + ModMain.MOD_ID + ".settings.model"),
                left, top + ROW_GAP * 3, 0xA0A0A0, false);

        if (!this.statusMessage.getString().isEmpty()) {
            graphics.drawCenteredString(this.font, this.statusMessage, this.width / 2,
                    top + ROW_GAP * 4 + 48, 0xFFFFFF);
        }
    }

    @Override
    public void onClose() {
        Minecraft minecraft = this.minecraft != null ? this.minecraft : Minecraft.getInstance();
        minecraft.setScreen(this.parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
package com.modbuilder.omniai_assistant;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Mengatur alur pesan antara pemain dan AI: menyimpan riwayat percakapan per
 * pemain, memanggil HTTP secara asinkron, kembali ke server thread, menampilkan
 * balasan dengan prefix "[AI]: " lalu mengekstrak dan menjadwalkan command.
 */
public final class ChatService {

    private static final String PREFIX = "[AI]: ";
    private static final int MAX_HISTORY_MESSAGES = 20;
    private static final int MAX_USER_MESSAGE_LENGTH = 2000;

    private static final Map<UUID, List<Map<String, String>>> HISTORY = new ConcurrentHashMap<>();
    private static final Set<UUID> PENDING = ConcurrentHashMap.newKeySet();

    private ChatService() {
    }

    /**
     * Dipanggil dari server thread ketika pemain mengirim pesan lewat /ai.
     */
    public static void handlePlayerMessage(ServerPlayer player, String rawMessage) {
        String message = rawMessage == null ? "" : rawMessage.trim();
        if (message.isEmpty()) {
            sendStatus(player, "Pesan tidak boleh kosong.", ChatFormatting.RED);
            return;
        }
        if (message.length() > MAX_USER_MESSAGE_LENGTH) {
            int end = MAX_USER_MESSAGE_LENGTH;
            if (Character.isHighSurrogate(message.charAt(end - 1))) {
                end--;
            }
            message = message.substring(0, end);
        }

        AiConfig config = AiConfig.get();
        if (config.provider.isApiKeyRequired() && (config.apiKey == null || config.apiKey.isBlank())) {
            sendStatus(player, "API key untuk " + config.provider.getLabel()
                    + " belum diisi. Buka pengaturan dengan /ai menu atau tombol K.", ChatFormatting.RED);
            return;
        }

        UUID id = player.getUUID();
        if (!PENDING.add(id)) {
            sendStatus(player, "Tunggu balasan sebelumnya selesai dulu.", ChatFormatting.YELLOW);
            return;
        }

        MinecraftServer server = player.getServer();
        if (server == null) {
            PENDING.remove(id);
            return;
        }

        try {
            String systemPrompt = PromptBuilder.build(player);
            List<Map<String, String>> snapshot = appendAndSnapshot(id, "user", message);

            sendStatus(player, "Sedang berpikir...", ChatFormatting.GRAY);

            AiHttpClient.chat(config, systemPrompt, snapshot).whenComplete((reply, error) ->
                    server.execute(() -> finish(server, id, reply, error)));
        } catch (RuntimeException e) {
            removeLastUserMessage(id);
            PENDING.remove(id);
            String detail = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
            ModMain.LOGGER.warn("Permintaan AI gagal dimulai untuk {}: {}", player.getGameProfile().getName(), detail);
            sendStatus(player, "Gagal menghubungi AI: " + detail, ChatFormatting.RED);
        }
    }

    /**
     * Menghapus riwayat percakapan seorang pemain, misalnya saat logout.
     */
    public static void clearHistory(UUID playerId) {
        HISTORY.remove(playerId);
        PENDING.remove(playerId);
    }

    /**
     * Menghapus semua riwayat, dipanggil ketika server berhenti.
     */
    public static void clearAll() {
        HISTORY.clear();
        PENDING.clear();
    }

    private static void finish(MinecraftServer server, UUID id, String reply, Throwable error) {
        PENDING.remove(id);
        ServerPlayer player = server.getPlayerList().getPlayer(id);
        if (player == null) {
            removeLastUserMessage(id);
            return;
        }

        if (error != null) {
            removeLastUserMessage(id);
            Throwable cause = error;
            while (cause instanceof CompletionException && cause.getCause() != null) {
                cause = cause.getCause();
            }
            String detail = cause.getMessage() == null ? cause.getClass().getSimpleName() : cause.getMessage();
            ModMain.LOGGER.warn("Permintaan AI gagal untuk {}: {}", player.getGameProfile().getName(), detail);
            sendStatus(player, "Gagal menghubungi AI: " + detail, ChatFormatting.RED);
            return;
        }

        if (reply == null || reply.isBlank()) {
            removeLastUserMessage(id);
            sendStatus(player, "AI mengirim balasan kosong.", ChatFormatting.YELLOW);
            return;
        }

        appendAndSnapshot(id, "assistant", reply);

        CommandExtractor.Result result = CommandExtractor.extract(reply);
        String visible = result.cleanText().trim();

        if (!visible.isEmpty()) {
            sendAiText(player, visible);
        } else if (!result.commands().isEmpty()) {
            sendAiText(player, "Baik, sedang dijalankan.");
        }

        if (!result.commands().isEmpty()) {
            CommandExecutor.enqueue(player, result.commands());
        }
    }

    private static List<Map<String, String>> appendAndSnapshot(UUID id, String role, String content) {
        List<Map<String, String>> history = HISTORY.computeIfAbsent(id, key -> new ArrayList<>());
        synchronized (history) {
            Map<String, String> entry = new HashMap<>();
            entry.put("role", role);
            entry.put("content", content);
            history.add(entry);
            while (history.size() > MAX_HISTORY_MESSAGES) {
                history.remove(0);
            }
            while (!history.isEmpty() && !"user".equals(history.get(0).get("role"))) {
                history.remove(0);
            }
            return new ArrayList<>(history);
        }
    }

    /**
     * Membuang pesan user terakhir bila permintaan gagal, agar riwayat tidak
     * berisi dua pesan user berurutan.
     */
    private static void removeLastUserMessage(UUID id) {
        List<Map<String, String>> history = HISTORY.get(id);
        if (history == null) {
            return;
        }
        synchronized (history) {
            if (!history.isEmpty() && "user".equals(history.get(history.size() - 1).get("role"))) {
                history.remove(history.size() - 1);
            }
        }
    }

    private static void sendAiText(ServerPlayer player, String text) {
        String[] lines = text.split("\\R");
        boolean first = true;
        for (String line : lines) {
            if (line.isBlank()) {
                continue;
            }
            MutableComponent component = Component.empty();
            if (first) {
                component.append(Component.literal(PREFIX).withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD));
                first = false;
            } else {
                component.append(Component.literal("      "));
            }
            component.append(Component.literal(line.stripTrailing()).withStyle(ChatFormatting.WHITE));
            player.sendSystemMessage(component);
        }
    }

    private static void sendStatus(ServerPlayer player, String text, ChatFormatting color) {
        MutableComponent component = Component.literal(PREFIX).withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD);
        component.append(Component.literal(text).withStyle(color));
        player.sendSystemMessage(component);
    }
}

package com.modbuilder.omniai_assistant;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public final class AiHttpClient {

    private static final Gson GSON = new Gson();
    private static final Duration CONNECT_TIMEOUT = Duration.ofSeconds(10);
    private static final Duration REQUEST_TIMEOUT = Duration.ofSeconds(90);
    private static final int MAX_ERROR_SNIPPET = 300;

    private static final AtomicInteger THREAD_COUNTER = new AtomicInteger();
    private static final ExecutorService EXECUTOR = Executors.newFixedThreadPool(3, runnable -> {
        Thread thread = new Thread(runnable, "OmniAI-HTTP-" + THREAD_COUNTER.incrementAndGet());
        thread.setDaemon(true);
        return thread;
    });

    private static final HttpClient CLIENT = HttpClient.newBuilder()
            .connectTimeout(CONNECT_TIMEOUT)
            .followRedirects(HttpClient.Redirect.NORMAL)
            .executor(EXECUTOR)
            .build();

    private AiHttpClient() {
    }

    public static final class ChatMessage {
        public final String role;
        public final String content;

        public ChatMessage(String role, String content) {
            this.role = role;
            this.content = content;
        }
    }

    public static class AiException extends RuntimeException {
        public AiException(String message) {
            super(message);
        }

        public AiException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    public static CompletableFuture<String> sendChat(AiConfig config, List<ChatMessage> messages) {
        final HttpRequest request;
        try {
            request = buildRequest(config, messages);
        } catch (AiException e) {
            return CompletableFuture.failedFuture(e);
        }

        return CLIENT.sendAsync(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8))
                .handle((response, error) -> {
                    if (error != null) {
                        throw translate(error);
                    }
                    return handleResponse(response);
                });
    }

    private static HttpRequest buildRequest(AiConfig config, List<ChatMessage> messages) {
        String url = config.endpointUrl == null ? "" : config.endpointUrl.trim();
        if (url.isEmpty()) {
            throw new AiException("URL server belum diatur. Buka menu dengan /ai menu.");
        }

        URI uri;
        try {
            uri = URI.create(url);
        } catch (IllegalArgumentException e) {
            throw new AiException("URL server tidak valid: " + url, e);
        }
        String scheme = uri.getScheme();
        if (scheme == null || !(scheme.equalsIgnoreCase("http") || scheme.equalsIgnoreCase("https"))) {
            throw new AiException("URL server harus diawali http:// atau https://");
        }

        String model = config.modelName == null ? "" : config.modelName.trim();
        if (model.isEmpty()) {
            throw new AiException("Nama model belum diatur. Buka menu dengan /ai menu.");
        }

        String apiKey = config.apiKey == null ? "" : config.apiKey.trim();
        if (config.provider.isApiKeyRequired() && apiKey.isEmpty()) {
            throw new AiException("API key untuk " + config.provider.getLabel() + " belum diatur. Buka menu dengan /ai menu.");
        }

        JsonObject body = new JsonObject();
        body.addProperty("model", model);
        body.addProperty("stream", false);
        JsonArray array = new JsonArray();
        for (ChatMessage message : messages) {
            JsonObject entry = new JsonObject();
            entry.addProperty("role", message.role);
            entry.addProperty("content", message.content);
            array.add(entry);
        }
        body.add("messages", array);

        HttpRequest.Builder builder = HttpRequest.newBuilder(uri)
                .timeout(REQUEST_TIMEOUT)
                .header("Content-Type", "application/json; charset=utf-8")
                .header("Accept", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(body), StandardCharsets.UTF_8));

        if (!apiKey.isEmpty()) {
            builder.header("Authorization", "Bearer " + apiKey);
        }
        return builder.build();
    }

    private static String handleResponse(HttpResponse<String> response) {
        int status = response.statusCode();
        String payload = response.body() == null ? "" : response.body();

        if (status < 200 || status >= 300) {
            throw new AiException(describeHttpError(status, payload));
        }
        return parseReply(payload);
    }

    private static String parseReply(String payload) {
        try {
            JsonElement root = GSON.fromJson(payload, JsonElement.class);
            if (root == null || !root.isJsonObject()) {
                throw new AiException("Balasan server kosong atau bukan JSON object.");
            }
            JsonObject object = root.getAsJsonObject();
            JsonArray choices = null;
            if (object.has("choices") && object.get("choices").isJsonArray()) {
                choices = object.getAsJsonArray("choices");
            }
            if (choices == null || choices.size() == 0) {
                throw new AiException("Balasan server tidak berisi 'choices'.");
            }
            JsonElement first = choices.get(0);
            if (!first.isJsonObject()) {
                throw new AiException("Format 'choices' tidak dikenali.");
            }
            JsonObject firstObject = first.getAsJsonObject();
            JsonObject message = null;
            if (firstObject.has("message") && firstObject.get("message").isJsonObject()) {
                message = firstObject.getAsJsonObject("message");
            }
            if (message == null || !message.has("content") || message.get("content").isJsonNull()) {
                throw new AiException("Balasan server tidak berisi teks.");
            }
            String content = message.get("content").getAsString().trim();
            if (content.isEmpty()) {
                throw new AiException("AI mengirim balasan kosong.");
            }
            return content;
        } catch (JsonParseException | IllegalStateException | UnsupportedOperationException e) {
            throw new AiException("Gagal membaca balasan server: " + e.getMessage(), e);
        }
    }

    private static String describeHttpError(int status, String payload) {
        String detail = extractErrorMessage(payload);
        String base;
        switch (status) {
            case 400:
                base = "Permintaan ditolak (400). Periksa nama model.";
                break;
            case 401:
                base = "API key salah atau tidak diterima (401).";
                break;
            case 403:
                base = "Akses ditolak (403). Periksa izin API key.";
                break;
            case 404:
                base = "Endpoint atau model tidak ditemukan (404).";
                break;
            case 408:
                base = "Server timeout (408).";
                break;
            case 429:
                base = "Terlalu banyak permintaan atau kuota habis (429).";
                break;
            default:
                if (status >= 500) {
                    base = "Server AI bermasalah (" + status + ").";
                } else {
                    base = "Error HTTP " + status + ".";
                }
                break;
        }
        return detail.isEmpty() ? base : base + " Detail: " + detail;
    }

    private static String extractErrorMessage(String payload) {
        if (payload == null || payload.isBlank()) {
            return "";
        }
        String text = payload.trim();
        try {
            JsonElement root = GSON.fromJson(text, JsonElement.class);
            if (root != null && root.isJsonObject()) {
                JsonElement error = root.getAsJsonObject().get("error");
                if (error != null && error.isJsonObject() && error.getAsJsonObject().has("message")) {
                    text = error.getAsJsonObject().get("message").getAsString();
                } else if (error != null && error.isJsonPrimitive()) {
                    text = error.getAsString();
                }
            }
        } catch (JsonParseException | IllegalStateException | UnsupportedOperationException ignored) {
            // Gunakan teks mentah jika bukan JSON yang valid.
        }
        text = text.replace('\n', ' ').replace('\r', ' ');
        if (text.length() > MAX_ERROR_SNIPPET) {
            text = text.substring(0, MAX_ERROR_SNIPPET) + "...";
        }
        return text;
    }

    private static AiException translate(Throwable error) {
        Throwable cause = error;
        while (cause instanceof CompletionException && cause.getCause() != null) {
            cause = cause.getCause();
        }
        if (cause instanceof AiException) {
            return (AiException) cause;
        }
        if (cause instanceof HttpTimeoutException) {
            return new AiException("Permintaan melewati batas waktu. Server terlalu lama menjawab.", cause);
        }
        if (cause instanceof java.net.ConnectException) {
            return new AiException("Tidak bisa terhubung ke server. Periksa URL dan koneksi internet.", cause);
        }
        if (cause instanceof IOException) {
            return new AiException("Kesalahan jaringan: " + cause.getMessage(), cause);
        }
        return new AiException("Kesalahan tak terduga: " + cause, cause);
    }

    public static void shutdown() {
        EXECUTOR.shutdownNow();
    }
}
package com.modbuilder.omniai_assistant;

import com.mojang.logging.LogUtils;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import org.slf4j.Logger;

@Mod("omniai_assistant")
public class ModMain {

    public static final String MOD_ID = "omniai_assistant";
    public static final String MOD_NAME = "OmniAI Assistant";
    public static final Logger LOGGER = LogUtils.getLogger();

    public ModMain(IEventBus modEventBus) {
        AiConfig.load();
        LOGGER.info("{} dimuat dengan provider {}", MOD_NAME, AiConfig.get().provider);

        modEventBus.addListener(NetworkHandler::register);

        if (FMLEnvironment.dist == Dist.CLIENT) {
            ClientSetup.init(modEventBus);
        }

        NeoForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        AiCommands.register(event.getDispatcher());
    }

    @SubscribeEvent
    public void onServerTick(ServerTickEvent.Post event) {
        CommandExecutor.tick(event.getServer());
    }

    @SubscribeEvent
    public void onPlayerLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            ChatService.clearHistory(player.getUUID());
            CommandExecutor.clearQueue(player.getUUID());
        }
    }

    @SubscribeEvent
    public void onServerStopping(ServerStoppingEvent event) {
        ChatService.clearAll();
        CommandExecutor.clearAll();
        LOGGER.info("{} dihentikan, riwayat dan antrean dibersihkan", MOD_NAME);
    }
}
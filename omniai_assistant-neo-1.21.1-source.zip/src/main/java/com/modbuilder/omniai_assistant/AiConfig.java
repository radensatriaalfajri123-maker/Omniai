package com.modbuilder.omniai_assistant;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import net.neoforged.fml.loading.FMLPaths;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

public class AiConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final String FILE_NAME = "omniai.json";

    private static volatile AiConfig instance = new AiConfig();

    public AiProvider provider = AiProvider.OPENAI;
    public String endpointUrl = AiProvider.OPENAI.getDefaultUrl();
    public String apiKey = "";
    public String modelName = "gpt-4o-mini";

    public static AiConfig get() {
        return instance;
    }

    private static Path configPath() {
        return FMLPaths.CONFIGDIR.get().resolve(FILE_NAME);
    }

    public static synchronized void load() {
        Path path = configPath();
        if (!Files.exists(path)) {
            instance = new AiConfig();
            save();
            return;
        }
        try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            AiConfig loaded = GSON.fromJson(reader, AiConfig.class);
            if (loaded == null) {
                loaded = new AiConfig();
            }
            loaded.sanitize();
            instance = loaded;
        } catch (IOException | JsonParseException e) {
            ModMain.LOGGER.error("Gagal membaca {}, memakai pengaturan default", path, e);
            instance = new AiConfig();
        }
    }

    public static synchronized void save() {
        Path path = configPath();
        Path tmp = path.resolveSibling(FILE_NAME + ".tmp");
        try {
            Files.createDirectories(path.getParent());
            try (Writer writer = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8)) {
                GSON.toJson(instance, writer);
            }
            try {
                Files.move(tmp, path, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicFail) {
                Files.move(tmp, path, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException e) {
            ModMain.LOGGER.error("Gagal menyimpan {}", path, e);
        }
    }

    public static synchronized void update(AiProvider provider, String url, String key, String model) {
        AiConfig next = new AiConfig();
        next.provider = provider;
        next.endpointUrl = url;
        next.apiKey = key;
        next.modelName = model;
        next.sanitize();
        instance = next;
        save();
    }

    public void sanitize() {
        if (provider == null) {
            provider = AiProvider.OPENAI;
        }
        endpointUrl = endpointUrl == null ? "" : endpointUrl.trim();
        if (endpointUrl.isEmpty()) {
            endpointUrl = provider.getDefaultUrl();
        }
        apiKey = apiKey == null ? "" : apiKey.trim();
        modelName = modelName == null ? "" : modelName.trim();
    }

    public boolean isUsable() {
        if (endpointUrl == null || endpointUrl.isBlank()) {
            return false;
        }
        if (modelName == null || modelName.isBlank()) {
            return false;
        }
        return !provider.isApiKeyRequired() || (apiKey != null && !apiKey.isBlank());
    }
}

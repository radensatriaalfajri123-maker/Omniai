package com.modbuilder.omniai_assistant;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayDeque;
import java.util.List;
import java.util.Locale;
import java.util.Queue;
import java.util.Set;
import java.util.UUID;

/**
 * Menjalankan command hasil balasan AI secara senyap di server thread.
 * Command dimasukkan ke antrean dan dieksekusi sedikit demi sedikit setiap tick
 * agar server tidak macet saat proyek bangunan besar.
 */
public final class CommandExecutor {

    /** Batas jumlah command yang diterima dari satu balasan AI. */
    public static final int MAX_COMMANDS_PER_REPLY = 40;

    /** Jumlah command yang dijalankan per tick. */
    private static final int COMMANDS_PER_TICK = 2;

    /** Batas total antrean untuk semua pemain. */
    private static final int MAX_QUEUE_SIZE = 400;

    /** Permission level minimum yang dibutuhkan pemain agar AI boleh menjalankan command. */
    private static final int REQUIRED_PERMISSION = 2;

    /** Command root yang tidak boleh dijalankan oleh AI. */
    private static final Set<String> BLOCKED_ROOTS = Set.of(
            "op", "deop", "stop", "ban", "ban-ip", "pardon", "pardon-ip",
            "whitelist", "kick", "save-off", "save-on", "save-all",
            "setidletimeout", "publish", "debug", "perf", "transfer",
            "reload", "datapack", "function", "execute", "ai",
            "gamerule", "defaultgamemode", "difficulty", "forceload",
            "jfr", "rcon", "banlist", "stopsound", "me", "msg", "tell", "w",
            "say", "teammsg", "tm",
            "return", "schedule", "tick"
    );

    private record Pending(UUID playerId, String command) {
    }

    private static final Queue<Pending> QUEUE = new ArrayDeque<>();

    private CommandExecutor() {
    }

    /**
     * Memasukkan daftar command ke antrean untuk pemain tertentu.
     * Harus dipanggil dari server thread.
     *
     * @return jumlah command yang benar-benar masuk antrean
     */
    public static int enqueue(ServerPlayer player, List<String> commands) {
        if (!player.hasPermissions(REQUIRED_PERMISSION)) {
            player.sendSystemMessage(Component.literal(
                    "[AI]: Kamu tidak punya izin untuk menjalankan command lewat AI."));
            return 0;
        }
        int accepted = 0;
        int skipped = 0;
        for (String raw : commands) {
            if (accepted >= MAX_COMMANDS_PER_REPLY || QUEUE.size() >= MAX_QUEUE_SIZE) {
                skipped++;
                continue;
            }
            String command = normalize(raw);
            if (command.isEmpty() || isBlocked(command)) {
                ModMain.LOGGER.warn("Command AI diblokir: {}", raw);
                skipped++;
                continue;
            }
            QUEUE.add(new Pending(player.getUUID(), command));
            accepted++;
        }
        if (skipped > 0) {
            player.sendSystemMessage(Component.literal(
                    "[AI]: " + skipped + " command dilewati (diblokir atau melebihi batas)."));
        }
        return accepted;
    }

    /** Dipanggil setiap akhir tick server. */
    public static void tick(MinecraftServer server) {
        int processed = 0;
        while (processed < COMMANDS_PER_TICK && !QUEUE.isEmpty()) {
            Pending pending = QUEUE.poll();
            processed++;
            ServerPlayer player = server.getPlayerList().getPlayer(pending.playerId());
            if (player == null) {
                continue;
            }
            run(server, player, pending.command());
        }
    }

    /** Mengosongkan antrean, misalnya saat server berhenti. */
    public static void clear() {
        QUEUE.clear();
    }

    /** Mengosongkan seluruh antrean untuk semua pemain. */
    public static void clearAll() {
        QUEUE.clear();
    }

    /** Membuang command yang masih antre milik satu pemain, misalnya saat logout. */
    public static void clearQueue(UUID playerId) {
        QUEUE.removeIf(pending -> pending.playerId().equals(playerId));
    }

    private static void run(MinecraftServer server, ServerPlayer player, String command) {
        try {
            if (!player.hasPermissions(REQUIRED_PERMISSION)) {
                return;
            }
            // Memakai permission asli pemain; tidak dinaikkan ke level 4.
            CommandSourceStack source = player.createCommandSourceStack()
                    .withSuppressedOutput();
            server.getCommands().performPrefixedCommand(source, command);
        } catch (Exception e) {
            ModMain.LOGGER.warn("Gagal menjalankan command AI '{}': {}", command, e.toString());
        }
    }

    private static String normalize(String raw) {
        if (raw == null) {
            return "";
        }
        String command = raw.trim();
        while (command.startsWith("/")) {
            command = command.substring(1).trim();
        }
        for (int i = 0; i < command.length(); i++) {
            if (Character.isISOControl(command.charAt(i))) {
                return "";
            }
        }
        return command;
    }

    private static boolean isBlocked(String command) {
        String lower = command.toLowerCase(Locale.ROOT);
        int space = lower.indexOf(' ');
        String root = space < 0 ? lower : lower.substring(0, space);
        int colon = root.indexOf(':');
        if (colon >= 0) {
            root = root.substring(colon + 1);
        }
        return BLOCKED_ROOTS.contains(root);
    }
}
